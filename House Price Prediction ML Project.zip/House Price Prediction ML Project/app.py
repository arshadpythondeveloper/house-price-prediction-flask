from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# model load
model = joblib.load("house_price_model.pkl")


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    area = float(request.form["area"])

    # prediction (IMPORTANT: 2D array)
    prediction = model.predict(np.array([[area]]))

    return render_template(
        "index.html",
        prediction_text=f"Predicted Price: {prediction[0]}"
    )


if __name__ == "__main__":
    app.run(debug=True)